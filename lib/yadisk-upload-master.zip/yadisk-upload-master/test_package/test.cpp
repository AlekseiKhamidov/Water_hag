#include <yandex/disk.hpp>

int main(int argc, char* argv[])
{
	yandex::disk::api disk_api("", false);
	return 0;
}

