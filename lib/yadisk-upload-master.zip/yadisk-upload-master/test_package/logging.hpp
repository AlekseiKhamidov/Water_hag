#define _(X) (X)
#define ELOG std::cout
#define ILOG std::cout
#define VLOG std::cout
