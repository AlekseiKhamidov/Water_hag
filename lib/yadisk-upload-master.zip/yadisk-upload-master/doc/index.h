﻿////////////////////////////////////////////////////////////////////////
// index.h
// Author: $username$ <$usermail$>
////////////////////////////////////////////////////////////////////////

/**

@image html main_logo.png
@author $username$ <$usermail$>
@date $date$

@mainpage yadisk-upload

@tableofcontents

@section intro Intro

@subsection desc Detail

@li @subpage pagename

*/
