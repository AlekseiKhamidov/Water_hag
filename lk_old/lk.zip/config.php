<?php

	const AMO_SUBDOMAIN = "fortunaperm";
	const AMO_LOGIN = "pos-credit@yandex.ru";  #Логин
	const AMO_HASH = "adcfe9a9c3a7ee623931d41b2d74b67e"; #Хэш для доступа к API

	const AMO_CFID_PARTNER = 14987;

	# Для подключения к MySQL
	const MYSQL_HOST = "localhost";
	const MYSQL_LOGIN = "root";
	const MYSQL_PASS = "";
	const MYSQL_DBNAME = "u0424882_default";
?>