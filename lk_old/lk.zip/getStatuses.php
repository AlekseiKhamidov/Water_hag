<?php
	include 'amoconn.php';
	echo makeStatusesJSON();
?>