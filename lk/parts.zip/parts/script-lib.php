<script type="text/javascript" src="../js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="../js/popper.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="../js/mdb.min.js"></script>
<script type="text/javascript" src="../js/materialize.min.js"></script>
<script src="lib/bootstrap-table-master/src/bootstrap-table.js"></script>
<script src="lib/bootstrap-table-master/src/extensions/filter-control/bootstrap-table-filter-control.js"></script>
<script src="lib/bootstrap-table-master/src/locale/bootstrap-table-ru-RU.js"></script>
<script type="text/javascript" src="js/filter.js"></script>
<script type="text/javascript" src="js/util-table.js"></script>
<script type="text/javascript" src="lib/bootstrap-table-master/src/extensions/export/bootstrap-table-export.js"></script>
<script type="text/javascript" src="js/tableExport.js"></script>
<script src="js/spin.min.js"></script>
<script src="js/extensions.js"></script>
<script type="text/javascript" src="../js/jquery.maskedinput.min.js"></script>
<script src="js/multiselect.js"></script>
<script src="js/jquery.color.min.js"></script>
