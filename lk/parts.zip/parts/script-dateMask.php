<script type="text/javascript">
  $(document).ready(function() {
    $(".datepickerMask").mask("99.99.9999", {placeholder: "ДД.ММ.ГГГГ" });
  });
</script>
